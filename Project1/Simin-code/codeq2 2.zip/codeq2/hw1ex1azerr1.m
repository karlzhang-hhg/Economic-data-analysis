function err = hw1ex1azerr(data,Tulim,p) % Tulim in no. of quarters

T = size(data,1);
n = size(data,2);

% condition on the first 5 periods. starting from the 6th row
y = data(1:Tulim,:);
ytrim = data((p+1):Tulim,:);
Tlen = size(ytrim,1);

Y = reshape(ytrim,Tlen*n,1);

x = zeros(Tlen,p*n+1);
x(:,1) = 1;
for i = 6:1:Tulim
    for j = 1:1:p
        x(i-5,(1+n*(j-1)+1):(1+(n*j))) = y(i-j,:);
    end;
end;

In = eye(n);

X = kron(In,x);

% mdl = LinearModel.fit(X,Y);
mdl = fitlm(X,Y,'Intercept',false);
betaols = mdl.Coefficients.Estimate; % return coeff


% predictions
h = 4;
ypred = [y;zeros(h,n)];
covmat = zeros(n,n*(n*p+1));
for k = 1:1:h
    for i = 1:1:n
        covmat(i,(i-1)*(n*p+1)+1) = 1;
        for j = 1:1:p
        covmat(i,((i-1)*(n*p+1)+(1+n*(j-1)+1)):((i-1)*(n*p+1)+(1+(n*j)))) ...
            = ypred(Tulim+k-j,:);        
        end;
    end;
    ypred(Tulim+k,:) = covmat*betaols;
end;

% compute avg growth rates

zhat = zeros(2,2); % z(n,h)
zhat(:,1) = 1/1 *(ypred(Tulim+1,1:2) - data(Tulim,1:2));
% zhat(2,1) = 1/1 *(ypred(Tulim+1,2) - data(Tulim,2));
zhat(:,2) = 1/4 *(ypred(Tulim+4,1:2) - data(Tulim,1:2));
% zhat(2,2) = 1/4 *(ypred(Tulim+4,2) - data(Tulim,2));

z = zeros(2,2); % z(n,h)
z(:,1) = 1/1 *(data(Tulim+1,1:2) - data(Tulim,1:2));
z(:,2) = 1/4 *(data(Tulim+4,1:2) - data(Tulim,1:2));

err = (zhat-z).^2;



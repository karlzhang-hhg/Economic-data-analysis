function mse = hw1ex1bzmse(data,p,fn) 


T = size(data,1);
n = size(data,2);

y11 = zeros(T-4-64,1);
y21 = zeros(T-4-64,1);

y12 = zeros(T-4-64,1);
y22 = zeros(T-4-64,1);

% errstk = fn(data,64,p);
% y11(1,1) = errstk(1,1);
% y21(1,1) = errstk(2,1);
% y12(1,1) = errstk(1,2);
% y22(1,1) = errstk(2,2);

xt = ((1974+0.25): 0.25: (2007))';
for Tulim = 65:1:(T-4)
    err = fn(data,Tulim,p);
%     errstk = cat(3,errstk,err);
    y11(Tulim-64,1) = err.error(1,1);
    y21(Tulim-64,1) = err.error(2,1);
    y12(Tulim-64,1) = err.error(1,2);
    y22(Tulim-64,1) = err.error(2,2);
    
    lam(Tulim-64,1) = err.optlam;
end;
% mse = errstk;
 mse(1,1) = mean(y11);
 mse(2,1) = mean(y21);
 mse(1,2) = mean(y12);
 mse(2,2) = mean(y22);
% d1 = digits(3);
% outmse = latex(vpa(sym(mse)));
% digits(d1);

% xt =  64:1:(T-4-1);
figure 
plot(xt,lam,'-.c');
title('Optimal Lambda')
axis([1959,2008,-inf,inf])

figure
subplot(2,2,1);
plot(xt,y11)
title('Estimation Sample Size vs MSFE')
axis([1959,2008,-inf,inf])

subplot(2,2,2);
plot(xt,y12)
axis([1959,2008,-inf,inf])

subplot(2,2,3);
plot(xt,y21)
axis([1959,2008,-inf,inf])

subplot(2,2,4);
plot(xt,y22)
axis([1959,2008,-inf,inf])
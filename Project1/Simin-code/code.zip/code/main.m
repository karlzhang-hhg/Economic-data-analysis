clear 
y=importdata('dataVARmedium.mat');
hw1ex2plot(y,5);
